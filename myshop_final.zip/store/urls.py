from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
]


path('cart/', views.view_cart, name='view_cart'),
path('add-to-cart/<int:product_id>/', views.add_to_cart, name='add_to_cart'),


path('register/', views.register_view, name='register'),
path('login/', views.login_view, name='login'),
path('logout/', views.logout_view, name='logout'),
path('pay/', views.pay, name='pay'),

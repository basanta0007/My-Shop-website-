from django.shortcuts import render
from .models import Product

def home(request):
    products = Product.objects.all()
    return render(request, 'store/home.html', {'products': products})


from django.shortcuts import redirect

def add_to_cart(request, product_id):
    cart = request.session.get('cart', {})
    cart[str(product_id)] = cart.get(str(product_id), 0) + 1
    request.session['cart'] = cart
    return redirect('home')

def view_cart(request):
    from .models import Product
    cart = request.session.get('cart', {})
    cart_items = []
    total = 0
    for id, qty in cart.items():
        product = Product.objects.get(id=id)
        cart_items.append({'product': product, 'quantity': qty, 'subtotal': product.price * qty})
        total += product.price * qty
    return render(request, 'store/cart.html', {'cart_items': cart_items, 'total': total})


import razorpay
from django.views.decorators.csrf import csrf_exempt
from django.conf import settings

@csrf_exempt
def pay(request):
    if request.method == 'POST':
        amount = int(float(request.POST['amount']) * 100)
        client = razorpay.Client(auth=("YOUR_RAZORPAY_KEY", "YOUR_RAZORPAY_SECRET"))
        payment = client.order.create({'amount': amount, 'currency': 'INR', 'payment_capture': 1})
        return render(request, 'store/checkout.html', {'payment': payment})


from django.contrib.auth import login, authenticate, logout
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm

def register_view(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            return redirect('home')
    else:
        form = UserCreationForm()
    return render(request, 'store/register.html', {'form': form})

def login_view(request):
    if request.method == 'POST':
        form = AuthenticationForm(data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)
            return redirect('home')
    else:
        form = AuthenticationForm()
    return render(request, 'store/login.html', {'form': form})

def logout_view(request):
    logout(request)
    return redirect('home')
